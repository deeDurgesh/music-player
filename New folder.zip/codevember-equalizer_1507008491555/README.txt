A Pen created at CodePen.io. You can find this one at https://codepen.io/arosenb2/pen/rOPNwa.

 An equalizer with a 3D effect