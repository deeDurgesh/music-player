A Pen created at CodePen.io. You can find this one at https://codepen.io/agathaco/pen/XezEOe.

 Loosely inspired by this post by Rachel Smith:
https://codepen.io/rachsmith/post/my-process-for-building-generative-pens

Used the same colours because they're so pretty!
Will also  add some mouse interaction later on.