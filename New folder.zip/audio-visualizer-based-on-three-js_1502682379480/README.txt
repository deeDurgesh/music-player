A Pen created at CodePen.io. You can find this one at https://codepen.io/prakhar625/pen/zddKRj.

 I wanted to use the Web Audio API, so made this music visualizer. The basic idea came from a pen I found here on codepen itself ( will link to it as soon as I find it ).

To use> Just upload any mp3 file and watch the bubble do weird things!

( Let me know what you think in the comments - good/bad/ugly )